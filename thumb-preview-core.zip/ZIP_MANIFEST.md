# Thumbnail/hover preview core bundle

Purpose: files relevant to thumbnail generation, thumbnail display, hover preview clips, runtime messaging, offscreen capture/recording, native helper contracts, and focused tests.

Missing requested files, if any:
- src/offscreen/__tests__/load-video-source.test.ts
